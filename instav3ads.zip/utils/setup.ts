//! enter your site details here

let SiteDetails = {
    "googleAnalytic": "UA-XXXXXXXX-X",
    "pub_id": "ca-pub-XXXXXXXXXXXXXXXX",
    "slot1": "xxxxx",
    "slot2": "xxxxx",
    'title': "Insta Xyz",
    'website': 'https://www.example.com',
    'website_name': 'insta',
    "api": "https://dummyapisds.herokuapp.com",
    "domain_extension": "com",
    'description': 'Example description',
    'profile': {
        'description': 'Example description',
        "title": ""
    },
    'video': {
        'description': 'Example description',
        "title": ""
    },
    'photo': {
        'description': 'Example description',
        "title": ""
    },
    'stories': {
        'description': 'Example description',
        "title": ""
    },
    'audio': {
        'description': 'Example description',
        "title": ""
    },
    "igtv": {
        'description': 'Example description',
        "title": ""
    },
     "reels": {
        'description': 'Example description',
        "title": ""
    }

}





export { SiteDetails }